package com.scristopher.myapppoema;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void salir (){
        finish();

    }

    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnLuis:

                Intent  intent = new Intent(this,MALuis.class);
                this.salir();
                startActivity(intent);
                break;

            case R.id.btnBatres:

                Intent  cB = new Intent(this,MABatres.class);
                this.salir();
                startActivity(cB);
                break;

            case R.id.btnMiguel:

                Intent  cM = new Intent(this, MAMiguel.class);
                this.salir();
                startActivity(cM);
                break;
        }

    }
}